import unittest
from conversion import dollars_to_dirhams, meters_to_kilometers

class TestConversionFunctions(unittest.TestCase):
    """
    Classe de tests unitaires pour les fonctions de conversion.
    """

    def test_dollars_to_dirhams(self):
        """
        Teste la conversion de dollars en dirhams.
        Vérifie que 5 dollars sont correctement convertis en 50 dirhams.
        """
        self.assertEqual(dollars_to_dirhams(5), 50)

    def test_meters_to_kilometers(self):
        """
        Teste la conversion de mètres en kilomètres.
        Vérifie que 500 mètres sont correctement convertis en 0.5 kilomètres.
        """
        self.assertEqual(meters_to_kilometers(500), 0.5)

# Point d'entrée principal pour exécuter les tests
if __name__ == "__main__":
    unittest.main()

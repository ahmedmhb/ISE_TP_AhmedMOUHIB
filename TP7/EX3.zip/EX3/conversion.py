def dollars_to_dirhams(dollars):
    """
    Convertit une somme en dollars en dirhams.

    Paramètres:
        dollars (float): La somme en dollars à convertir.

    Retourne:
        float: La somme convertie en dirhams (approximation : 1 dollar = 10 dirhams).
    """
    return dollars * 10

def meters_to_kilometers(meters):
    """
    Convertit une distance en mètres en kilomètres.

    Paramètres:
        meters (float): La distance en mètres à convertir.

    Retourne:
        float: La distance convertie en kilomètres.
    """
    return meters * (10 ** -3)
